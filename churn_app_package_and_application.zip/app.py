
import tkinter as tk
from tkinter import ttk, messagebox
import pickle
import numpy as np
import pandas as pd
import os

HERE = os.path.dirname(os.path.abspath(__file__))

# Load model & encoders
with open(os.path.join(HERE, "customer_churn_model.pkl"), "rb") as f:
    model_data = pickle.load(f)
model = model_data["model"]
FEATURES = model_data.get("features_names", None)

encoders = {}
enc_path = os.path.join(HERE, "encoders.pkl")
if os.path.exists(enc_path):
    with open(enc_path, "rb") as f:
        encoders = pickle.load(f)

# Basic GUI-building utility
root = tk.Tk()
root.title("Telco Customer Churn - Prediction")
root.geometry("760x560")

mainframe = ttk.Frame(root, padding="12 12 12 12")
mainframe.grid(column=0, row=0, sticky=(tk.N, tk.W, tk.E, tk.S))
root.columnconfigure(0, weight=1)
root.rowconfigure(0, weight=1)

# Input fields (kept minimal — map to common features)
# We will attempt to handle unknowns by zero-filling missing features
inputs = {}
def add_label_combo(row, label, options, var_name, default=None):
    ttk.Label(mainframe, text=label).grid(column=0, row=row, sticky=tk.W, padx=4, pady=6)
    v = tk.StringVar(value=default if default is not None else options[0])
    cb = ttk.Combobox(mainframe, textvariable=v, values=options, state="readonly", width=28)
    cb.grid(column=1, row=row, sticky=(tk.W))
    inputs[var_name] = v

def add_label_entry(row, label, var_name, default=""):
    ttk.Label(mainframe, text=label).grid(column=0, row=row, sticky=tk.W, padx=4, pady=6)
    v = tk.StringVar(value=default)
    e = ttk.Entry(mainframe, textvariable=v, width=30)
    e.grid(column=1, row=row, sticky=(tk.W))
    inputs[var_name] = v

# Create fields (common ones from Telco dataset)
add_label_combo(0, "Gender", ["Female", "Male"], "gender", "Male")
add_label_combo(1, "Senior Citizen", ["0", "1"], "SeniorCitizen", "0")
add_label_combo(2, "Partner", ["No", "Yes"], "Partner", "No")
add_label_combo(3, "Dependents", ["No", "Yes"], "Dependents", "No")
add_label_combo(4, "Phone Service", ["No", "Yes"], "PhoneService", "Yes")
add_label_combo(5, "Multiple Lines", ["No phone service", "No", "Yes"], "MultipleLines", "No")
add_label_combo(6, "Internet Service", ["No", "DSL", "Fiber optic"], "InternetService", "DSL")
add_label_combo(7, "Online Security", ["No internet service", "No", "Yes"], "OnlineSecurity", "No")
add_label_combo(8, "Online Backup", ["No internet service", "No", "Yes"], "OnlineBackup", "No")
add_label_combo(9, "Device Protection", ["No internet service", "No", "Yes"], "DeviceProtection", "No")
add_label_combo(10, "Tech Support", ["No internet service", "No", "Yes"], "TechSupport", "No")
add_label_combo(11, "Streaming TV", ["No internet service", "No", "Yes"], "StreamingTV", "No")
add_label_combo(12, "Streaming Movies", ["No internet service", "No", "Yes"], "StreamingMovies", "No")
add_label_combo(13, "Contract", ["Month-to-month", "One year", "Two year"], "Contract", "Month-to-month")
add_label_combo(14, "Paperless Billing", ["No", "Yes"], "PaperlessBilling", "Yes")
add_label_combo(15, "Payment Method", ["Electronic check","Mailed check","Bank transfer (automatic)","Credit card (automatic)"], "PaymentMethod", "Electronic check")

add_label_entry(16, "Tenure (months)", "tenure", "12")
add_label_entry(17, "Monthly Charges", "MonthlyCharges", "50.0")
add_label_entry(18, "Total Charges", "TotalCharges", "600.0")

# Output area
out_frame = ttk.LabelFrame(mainframe, text="Prediction", padding="10 10 10 10")
out_frame.grid(column=2, row=0, rowspan=8, padx=12, pady=12, sticky=(tk.N, tk.E))

pred_text = tk.Text(out_frame, width=36, height=14, wrap="word")
pred_text.grid(column=0, row=0)

def preprocess_and_predict():
    # Build input dict
    data = {}
    for k,v in inputs.items():
        val = v.get()
        # map numeric-looking fields
        if k in ["tenure","MonthlyCharges","TotalCharges"]:
            try:
                data[k] = float(val)
            except:
                data[k] = 0.0
        else:
            data[k] = val

    # Create DataFrame with columns matching FEATURES if possible
    if FEATURES is None:
        # no feature names: try simple column ordering
        X = pd.DataFrame([data])
    else:
        X = pd.DataFrame([data])
        # Apply encoders if available
        for col, enc in encoders.items():
            if col in X.columns:
                # If value not in classes_, pick first class then transform
                val = X.loc[0,col]
                if val not in enc.classes_:
                    # find a closest fallback
                    X.loc[0,col] = enc.classes_[0]
                else:
                    X.loc[0,col] = val
                try:
                    X.loc[:,col] = enc.transform(X.loc[:,col])
                except Exception:
                    # If transform fails, map unknowns to zero
                    X.loc[:,col] = 0

        # Ensure all FEATURES exist
        for f in FEATURES:
            if f not in X.columns:
                X[f] = 0

        X = X[FEATURES]

    # Make prediction
    try:
        pred = model.predict(X)[0]
        proba = model.predict_proba(X)[0][1] if hasattr(model, "predict_proba") else None
    except Exception as e:
        messagebox.showerror("Model error", f"Prediction failed: {e}")
        return

    # Display
    pred_text.delete("1.0", tk.END)
    pred_text.insert(tk.END, f"Prediction: {'Churn' if pred==1 else 'No Churn'}\\n")
    if proba is not None:
        pred_text.insert(tk.END, f"Churn probability: {proba:.4f}\\n")
        conf = "high" if proba>=0.7 or proba<=0.3 else ("medium" if proba>=0.6 or proba<=0.4 else "low")
        pred_text.insert(tk.END, f"Confidence: {conf}\\n")
    pred_text.insert(tk.END, "\\nInput summary:\\n")
    for k in data:
        pred_text.insert(tk.END, f"- {k}: {data[k]}\\n")

# Buttons
btn_frame = ttk.Frame(mainframe)
btn_frame.grid(column=0, row=20, columnspan=2, pady=10)
ttk.Button(btn_frame, text="Predict", command=preprocess_and_predict).grid(column=0, row=0, padx=8)
ttk.Button(btn_frame, text="Quit", command=root.destroy).grid(column=1, row=0, padx=8)

# Padding
for child in mainframe.winfo_children():
    child.grid_configure(padx=6, pady=4)

root.mainloop()
